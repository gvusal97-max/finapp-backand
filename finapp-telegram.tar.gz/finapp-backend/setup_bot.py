"""
Run once after deploy to configure the bot:
  python setup_bot.py

What it does:
  1. Sets bot commands (/start, /app, /help)
  2. Sets bot description
  3. Sets Menu Button → opens the Mini App
"""
import os
import sys
import requests

BOT_TOKEN = os.getenv("BOT_TOKEN")
MINI_APP_URL = os.getenv("MINI_APP_URL")  # e.g. https://your-app.railway.app

if not BOT_TOKEN or not MINI_APP_URL:
    print("❌ Set BOT_TOKEN and MINI_APP_URL environment variables")
    sys.exit(1)

BASE = f"https://api.telegram.org/bot{BOT_TOKEN}"


def call(method, **kwargs):
    r = requests.post(f"{BASE}/{method}", json=kwargs)
    data = r.json()
    if not data.get("ok"):
        print(f"  ❌ {method}: {data.get('description')}")
    else:
        print(f"  ✅ {method}")
    return data


print("🤖 Configuring bot...")

# 1. Commands
call("setMyCommands", commands=[
    {"command": "start",  "description": "Открыть FinApp"},
    {"command": "app",    "description": "Запустить финансовый дашборд"},
    {"command": "help",   "description": "Помощь"},
])

# 2. Description
call("setMyDescription",
     description="💼 FinApp Business — финансовый дашборд прямо в Telegram.\n\nВсе банковские счета, cash flow, CRM и AI-ассистент в одном приложении.")

call("setMyShortDescription",
     short_description="Финансовый дашборд и CRM для бизнеса")

# 3. Menu button → Mini App
call("setChatMenuButton", menu_button={
    "type": "web_app",
    "text": "💼 FinApp",
    "web_app": {"url": MINI_APP_URL}
})

print(f"\n✅ Done! Open https://t.me/{os.getenv('BOT_USERNAME', 'your_bot')} to test")
print(f"   Mini App URL: {MINI_APP_URL}")
