# 🚀 Деплой FinApp в Telegram — пошаговая инструкция

## Шаг 1 — Создай бота (уже сделал?)

1. Открой Telegram → @BotFather
2. /newbot → придумай имя и username
3. Скопируй токен: `7123456789:AAF...`

---

## Шаг 2 — Деплой бэкенда на Railway (бесплатно)

1. Зайди на **railway.app** → Sign in with GitHub
2. New Project → Deploy from GitHub repo
   (или: "Deploy from local" — загрузи папку `finapp-backend/`)
3. В настройках проекта добавь переменные окружения:
   ```
   BOT_TOKEN = 7123456789:AAF...твой_токен...
   JWT_SECRET = придумай-длинную-строку-32-символа
   ```
4. Railway даст URL вида: `https://finapp-backend-production.up.railway.app`
   Скопируй его — это и есть твой MINI_APP_URL

---

## Шаг 3 — Загрузи Mini App (HTML)

**Вариант А — Railway (рекомендую, всё в одном):**
1. Создай папку `static/` внутри `finapp-backend/`
2. Положи туда `finapp_v2.html`, переименуй в `index.html`
3. Задеплой снова — бэкенд сам отдаёт HTML

**Вариант Б — GitHub Pages (бесплатно, отдельно):**
1. Создай репозиторий на github.com
2. Загрузи `finapp_v2.html` как `index.html`
3. Settings → Pages → Branch: main → Save
4. Получишь URL: `https://твой-username.github.io/finapp/`

---

## Шаг 4 — Настрой бота

Запусти один раз (нужен Python):
```bash
cd finapp-backend
pip install requests
BOT_TOKEN="твой_токен" MINI_APP_URL="https://твой-url.railway.app" python setup_bot.py
```

Или вручную через @BotFather:
- /setmenubutton → выбери бота → Web App → вставь URL

---

## Шаг 5 — Проверь

1. Открой бота в Telegram
2. Нажми кнопку меню (левый нижний угол в чате с ботом)
3. Должен открыться FinApp 🎉

---

## Если что-то не работает

- Проверь `/api/health` — должно вернуть `{"status":"ok"}`
- URL должен быть HTTPS (Railway даёт автоматически)
- Убедись что BOT_TOKEN без лишних пробелов

---

## Структура файлов

```
finapp-backend/
  main.py          ← FastAPI сервер
  setup_bot.py     ← Настройка бота (запустить 1 раз)
  requirements.txt
  railway.toml
  Procfile
  static/
    index.html     ← finapp_v2.html сюда
```
