import os
import hmac
import hashlib
import json
import time
from urllib.parse import unquote
from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Optional
import jwt

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
JWT_SECRET = os.getenv("JWT_SECRET", "change-me-in-production")
JWT_EXPIRE = 60 * 60 * 24 * 7  # 7 days

app = FastAPI(title="FinApp API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Telegram initData verification ────────────────────────
def verify_telegram_init_data(init_data: str) -> dict:
    """
    Verify Telegram WebApp initData using HMAC-SHA256.
    https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
    """
    if not BOT_TOKEN:
        raise HTTPException(400, "BOT_TOKEN not configured")

    parsed = {}
    for part in init_data.split("&"):
        if "=" in part:
            k, v = part.split("=", 1)
            parsed[unquote(k)] = unquote(v)

    received_hash = parsed.pop("hash", None)
    if not received_hash:
        raise HTTPException(401, "Missing hash")

    # Build data-check-string
    data_check = "\n".join(f"{k}={v}" for k, v in sorted(parsed.items()))

    # HMAC key = HMAC-SHA256("WebAppData", bot_token)
    secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    expected = hmac.new(secret_key, data_check.encode(), hashlib.sha256).hexdigest()

    if not hmac.compare_digest(expected, received_hash):
        raise HTTPException(401, "Invalid hash — data tampered")

    # Check auth_date freshness (max 24h)
    auth_date = int(parsed.get("auth_date", 0))
    if time.time() - auth_date > 86400:
        raise HTTPException(401, "initData expired")

    user_data = json.loads(parsed.get("user", "{}"))
    return user_data


def create_jwt(user_id: int, username: str) -> str:
    payload = {
        "sub": str(user_id),
        "username": username,
        "exp": int(time.time()) + JWT_EXPIRE,
        "iat": int(time.time()),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")


def verify_jwt(token: str) -> dict:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(401, "Invalid token")


def get_current_user(request: Request) -> dict:
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        raise HTTPException(401, "Missing token")
    return verify_jwt(auth[7:])


# ── Models ────────────────────────────────────────────────
class TelegramAuthRequest(BaseModel):
    initData: str

class TokenResponse(BaseModel):
    token: str
    user: dict


# ── Auth endpoints ────────────────────────────────────────
@app.post("/api/auth/telegram", response_model=TokenResponse)
async def auth_telegram(body: TelegramAuthRequest):
    user = verify_telegram_init_data(body.initData)
    token = create_jwt(user["id"], user.get("username", ""))
    return {"token": token, "user": user}


@app.get("/api/auth/me")
async def auth_me(current_user: dict = Depends(get_current_user)):
    return current_user


# ── Health check ──────────────────────────────────────────
@app.get("/api/health")
async def health():
    return {"status": "ok", "bot_configured": bool(BOT_TOKEN)}


# ── Serve Mini App static files ───────────────────────────
# In production, put your built finapp.html in /app/static/
if os.path.exists("static"):
    app.mount("/", StaticFiles(directory="static", html=True), name="static")
